SELECT  Name
FROM `worldnew`.`city`
Limit 20;
